# IPLSentimentAlalysis

How to run get tweets?

python get_tweets.py > tweets.txt